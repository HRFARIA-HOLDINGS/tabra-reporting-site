import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const API_BASE = "https://script.google.com/macros/s/AKfycbzl6LvvbOmUOZF_CW1SRtSGoRMIYGNMewR_Gf6Kk0RvIsQFi90WRWM2lQJwPk8E_JeJtA/exec";

export default function LoginPage() {
  const [form, setForm] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    const res = await fetch(`${API_BASE}?action=login`, {
      method: "POST",
      body: JSON.stringify(form),
      headers: { "Content-Type": "application/json" }
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem("username", form.username);
      localStorage.setItem("role", data.role);
      navigate(data.role === "admin" ? "/admin" : "/user");
    } else {
      setError("Invalid username or password");
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 space-y-4 mt-10">
      <h1 className="text-3xl font-bold text-center">Tabra Realty LLP - Login</h1>
      <Input placeholder="Username" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} />
      <Input type="password" placeholder="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
      <Button onClick={handleLogin} className="w-full">Login</Button>
      {error && <p className="text-red-500 text-center">{error}</p>}
    </div>
  );
}